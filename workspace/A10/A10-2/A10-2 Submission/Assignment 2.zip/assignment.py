import numpy as np
from soundAnalysis import descriptorPairScatterPlot as descSP
from soundAnalysis import clusterSounds as CS
from soundAnalysis import clusterSoundsRes as CSr # resumed output for ease of calculation
from soundDownload import downloadSoundsFreesound as downFS
from soundAnalysis import fetchDataDetails

APIKey = 'your_key_here'

# Question 1

def Q1():
    """Download of sounds for Question 1."""
    outputDir = 'downloads/' # first, the folder has to be created
    text_tag = {'naobo':'beijing-opera', 'acoustic_guitar':'1-shot', 'trumpet':'single-note', 'violin':'single-note', 'cello':'single-note', 'snare_pearl':'', 'transverse_flute':'', 'bassoon':'', 'xiaoluo':'beijing-opera', 'clarinet':'single-note'}

    for key in text_tag:
        print('Downloading ' + key + ' sounds...')
        downFS(outputDir='downloads/', queryText=key, tag=text_tag[key], API_Key=APIKey, topNResults=20, duration=(0.5, 8))
    return

# Question 2

def Q2():
    """ Clustering calculation."""
    CS('downloads', 10, descInput=[3,1,13]) 
    # 68.5% maximum accuracy obtained
    return

# Question 3

fs = 44100.0

import essentia.standard as ess
import matplotlib.pyplot as plt
import os, sys
import json

def Q3():
    CSr('downloads/', descInput=[13, 14, 31])
    # 75% maximum accuracy obtained
    # Other good parameters:
    # 3 5 9 10 18 21 22 23 29 34 
    return

def computeEnergy(x, H=128, N=2**12, M=2**10, type='hann'):
    """ 
    Computes the spectrum and energy of the input
    audio signal and returns both of them along with
    the framed input audio.
    """
    Egy = []
    mX = []
    frames = []
    spectrum = ess.Spectrum(size=N)
    energy = ess.Energy()
    window = ess.Windowing(size=M, type=type)
    for frame in ess.FrameGenerator(x, frameSize=M, hopSize=H, startFromZero=True):          
        mag = spectrum(window(frame))
        if isinstance(mX, list):
            mX = mag
            frames = frame
        else:
            mX = np.vstack((mX, mag))
            frames = np.vstack((frames, frame))
        egy = energy(mag)
        Egy.append(egy)
    return mX, np.asarray(Egy), frames

def plotEnergySample(t=0.002, H=128):
    """
    Plots some sample energies from randomly picked instruments
    downloaded for the assignment, yields one plot per two 
    sounds.
    """
    for i in np.arange(6)+1:
        filename = 'samples/s' + str(i) + '.mp3'
        print('loading ' + filename[8:])
        x = ess.MonoLoader(filename=filename, sampleRate=fs)()
        mX, energy = computeEnergy(x)
        plt.figure((i+1)//2)
        plt.plot(H*np.arange(len(energy))/fs, energy, linewidth=2, label='energy sample ' + str(i))
        if (i+1)%2 == 1:
            plt.plot(H*np.arange(len(energy))/fs, np.ones(len(energy))*t, '--', linewidth=2, label='threshold')
            plt.ylabel('Energy')
            plt.xlabel('Time')
        plt.legend()
    plt.show()
    return

def frameEnergyThreshold(x, thr=0.002, H=128, N=2**12, M=2**10, type='hann'):
    """
    Computes the magnitude spectrum of the STFT, and 
    returns the frames of the sound where it is above 
    the threshold.
    """
    mX, energy, frames = computeEnergy(x, H, N, M, type)
    
    idx_sup = np.where(energy>thr)[0] # indexes where energy is above threshold
    try:
        return frames[idx_sup[0]: idx_sup[-1], :]
    except:
        return frames

def parameterReference():
    """ Reference dictionary for the parameters calculated."""
    out_dict = {
        0: 'barkbands_kurtosis.mean',
        1: 'barkbands_skewness.mean',
        2: 'barkbands_spread.mean',
        3: 'hfc.mean',
        4: 'pitch.mean',
        5: 'pitch_salience.mean',
        6: 'spectral_complexity.max.mean',
        7: 'spectral_crest.mean.mean',
        8: 'spectral_decrease.mean',
        9: 'spectral_energy.mean',
        10: 'spectral_energyband_low.mean',
        11: 'spectral_energyband_middle_low.mean',
        12: 'spectral_energyband_middle_high.mean',
        13: 'spectral_energyband_high.mean',
        14: 'spectral_flatness_db.mean',
        15: 'spectral_flux.mean',
        16: 'spectral_rms.mean',
        17: 'spectral_rolloff.mean',
        18: 'spectral_strongpeak.mean',
        19: 'zerocrossingrate.mean',
        20: 'inharmonicity_(recalc).mean',
        21: 'tristimulus_first.mean',
        22: 'tristimulus_second.mean',
        23: 'tristimulus_third.mean',
        24: 'oddtoevenharmonicenergyratio.mean'
    }
    return out_dict

def calculateParameters(x, thr=0.002, H=128, N=2**12, M=2**10, type='hann'):
    """Returns a list containing 25 numpy arrays corresponding
    to 25 Low Level Spectral descriptors, for each frame of
    the input x. To compute the parameters the function
    LowLevelSpectralExtractor from essentia is used.
    """
    bb_k = []
    bb_sk = []
    bb_sp = []
    hfc = []
    pi = []
    pi_sl = []
    s_cx = []
    s_cr = [] 
    s_d = []
    s_e = []
    s_el = []
    s_eml = []
    s_emh = []
    s_eh = []
    s_fdb = []
    s_fx = []
    s_rms = []
    s_ro = []
    s_sp = []
    zcr = []
    ih = []
    tr1 = []
    tr2 = []
    tr3 = []
    oe_hr = []
    LLSE = ess.LowLevelSpectralExtractor()
    for frame in frameEnergyThreshold(x, thr, H, N, M, type):
        params = LLSE(frame)   
        bb_k.append(np.mean(params[1]))
        bb_sk.append(np.mean(params[2]))
        bb_sp.append(np.mean(params[3]))
        hfc.append(np.mean(params[4]))
        pi.append(np.mean(params[6]))
        pi_sl.append(np.mean(params[8]))
        s_cx.append(np.mean(params[12]))
        s_cr.append(np.mean(params[13]))
        s_d.append(np.mean(params[14]))
        s_e.append(np.mean(params[15]))
        s_el.append(np.mean(params[16]))
        s_eml.append(np.mean(params[17]))
        s_emh.append(np.mean(params[18]))
        s_eh.append(np.mean(params[19]))
        s_fdb.append(np.mean(params[20]))
        s_fx.append(np.mean(params[21]))
        s_rms.append(np.mean(params[22]))
        s_ro.append(np.mean(params[23]))
        s_sp.append(np.mean(params[24]))
        zcr.append(np.mean(params[25]))
        ih.append(np.mean(params[26]))
        tr1.append(np.mean(params[27][:,0]))
        tr2.append(np.mean(params[27][:,1]))
        tr3.append(np.mean(params[27][:,2]))
        oe_hr.append(np.mean(params[28]))
    aux_out_list = [bb_k, bb_sk, bb_sp, hfc, pi, pi_sl, s_cx, s_cr, s_d, s_e, s_el, s_eml, s_emh, s_eh, s_fdb, s_fx, s_rms, s_ro, s_sp, zcr, ih, tr1, tr2, tr3, oe_hr]
    out_list = []
    for param in aux_out_list:
        out_list.append(np.asarray(np.mean(param))) # Outputs the mean for all frames of each parameters
    return out_list

def addParameters(directory):
    """
    This function loads all sounds in the specified directory, and after calculating 
    the low level spectral parameters, adds them to...
    """
    dataDetails = fetchDataDetails(directory)
    parameterRef = parameterReference()
    for cname in dataDetails.keys():
        # Iterating over sounds
        for sname in dataDetails[cname].keys():
            audioPath = directory + cname + '/' + sname + '/' + dataDetails[cname][sname]['file'].split('.')[0] + '.mp3'
            jsonPath = audioPath.split('.')[0] + '.json'
            x = ess.MonoLoader(filename=audioPath, sampleRate=fs)()
            new_params = calculateParameters(x) # parameter calculations
            # open existing dictionaries and append new values
            with open(jsonPath) as jsonFile:
                fDict = json.load(jsonFile)
                for key in parameterRef.keys():
                    fDict[parameterRef[key]] = [new_params[key].tolist()]
            # save modified dictionary
            with open(jsonPath, 'w') as jsonFile:
                json.dump(fDict, jsonFile)                
    return
